package com.example.demo;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cgi.repository.QuestionRepository;
import com.cgi.model.Question;

@SpringBootTest
class CGIRecruitmentPlateformApplicationTests {
	
	@Autowired
	QuestionRepository qs;

	@Test
	public void testgetAll() {
		qs.save(new Question());
		List<Question> s=qs.findAll();
		assertEquals(s.size(),1);
	}

}
