package com.cgi.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.cgi.model.Question;

@Repository
public interface QuestionRepository extends MongoRepository<Question,String>  {

}
