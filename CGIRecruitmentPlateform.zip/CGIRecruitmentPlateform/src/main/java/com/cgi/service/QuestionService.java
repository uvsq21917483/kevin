package com.cgi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cgi.model.Question;

@Service
public interface QuestionService {
	
	List<Question> AllQuestions();
	Question saveQuestion(Question qs);
	Question findQuestionById(String id);
	void deleteQuestion(String id);
	Question updateQuestion(String id, Question question);
	
}
